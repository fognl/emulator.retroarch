
#define compositeConnection
// #define noScanlines

#define signalResolution		256.0
#define signalResolutionI		83.0
#define signalResolutionQ		25.0
#define tvVerticalResolution	250.0

#define blackLevel 0.0875
#define contrast 1.0

#define FIXNUM 6
