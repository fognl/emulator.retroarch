LCD Shader v0.0.1 
=======
This shader for RetroArch is intended to simulate a general LCD screen, loosely based on the GBA. It's a very early build and may have issues with some graphics hardware. Check the .cg files for configuration options listed under the config headers.

Instructions
--------------

In RetroArch's shader options, load the `lcd_shader.cgp` file found in the `lcd_shader/` directory.
